#include "add.h"

int addition(const BigInt *a, const BigInt *b, BigInt *result)
{
    BigInt temp;
    bigint_init(&temp);

    if (a->sign == 0)
    {
        bigint_clear(result);
        /* Copy b into result without sharing nodes. */
        for (Dlist *p = b->head; p != NULL; p = p->next)
            append_digit(result, p->digit);
        if (result->head == NULL)
            append_digit(result, 0);
        result->sign = b->sign;
        bigint_normalize(result);
        return 1;
    }
    if (b->sign == 0)
    {
        bigint_clear(result);
        for (Dlist *p = a->head; p != NULL; p = p->next)
            append_digit(result, p->digit);
        result->sign = a->sign;
        bigint_normalize(result);
        return 1;
    }

    if (a->sign == b->sign)
    {
        add_abs(a, b, &temp);
        temp.sign = a->sign;
    }
    else
    {
        int cmp = compare_abs(a, b);
        if (cmp == 0)
        {
            bigint_parse(&temp, "0");
        }
        else if (cmp > 0)
        {
            sub_abs(a, b, &temp);
            temp.sign = a->sign;
        }
        else
        {
            sub_abs(b, a, &temp);
            temp.sign = b->sign;
        }
    }

    bigint_clear(result);
    *result = temp;
    bigint_normalize(result);
    return 1;
}