#include "main.h"

void bigint_init(BigInt *n)
{
    n->head = NULL;
    n->tail = NULL;
    n->sign = 0;
}

void bigint_clear(BigInt *n)
{
    Dlist *cur = n->head;
    while (cur != NULL)
    {
        Dlist *next = cur->next;
        free(cur);
        cur = next;
    }
    n->head = NULL;
    n->tail = NULL;
    n->sign = 0;
}

void append_digit(BigInt *n, int digit)
{
    Dlist *node = malloc(sizeof(*node));
    if (node == NULL)
        return;

    node->digit = digit;
    node->next = NULL;
    node->prev = n->tail;

    if (n->tail != NULL)
        n->tail->next = node;
    else
        n->head = node;

    n->tail = node;
}

void prepend_digit(BigInt *n, int digit)
{
    Dlist *node = malloc(sizeof(*node));
    if (node == NULL)
        return;

    node->digit = digit;
    node->prev = NULL;
    node->next = n->head;

    if (n->head != NULL)
        n->head->prev = node;
    else
        n->tail = node;

    n->head = node;
}

int bigint_is_zero(const BigInt *n)
{
    return n->head == NULL ||
           (n->head == n->tail && n->head->digit == 0);
}

void bigint_normalize(BigInt *n)
{
    while (n->head != NULL && n->head->digit == 0 && n->head != n->tail)
    {
        Dlist *old = n->head;
        n->head = old->next;
        n->head->prev = NULL;
        free(old);
    }

    if (n->head == NULL)
    {
        append_digit(n, 0);
    }

    if (bigint_is_zero(n))
        n->sign = 0;
    else if (n->sign == 0)
        n->sign = 1;
}

int bigint_parse(BigInt *n, const char *text)
{
    const char *p = text;
    int sign = 1;
    bigint_clear(n);

    if (p == NULL || *p == '\0')
        return 0;

    if (*p == '+' || *p == '-')
    {
        if (*p == '-')
            sign = -1;
        p++;
    }

    if (*p == '\0')
        return 0;

    for (const char *q = p; *q != '\0'; q++)
    {
        if (!isdigit((unsigned char)*q))
        {
            bigint_clear(n);
            return 0;
        }
    }

    while (*p == '0' && p[1] != '\0')
        p++;

    while (*p != '\0')
    {
        append_digit(n, *p - '0');
        if (n->tail == NULL)
        {
            bigint_clear(n);
            return 0;
        }
        p++;
    }

    n->sign = sign;
    bigint_normalize(n);
    return 1;
}

void bigint_print(const BigInt *n)
{
    if (n->sign < 0)
        putchar('-');

    if (n->head == NULL)
    {
        putchar('0');
        return;
    }

    for (Dlist *cur = n->head; cur != NULL; cur = cur->next)
        printf("%d", cur->digit);
}

int compare_abs(const BigInt *a, const BigInt *b)
{
    Dlist *x = a->head, *y = b->head;
    int len_a = 0, len_b = 0;

    while (x != NULL) { len_a++; x = x->next; }
    while (y != NULL) { len_b++; y = y->next; }

    if (len_a != len_b)
        return len_a > len_b ? 1 : -1;

    x = a->head;
    y = b->head;
    while (x != NULL && y != NULL)
    {
        if (x->digit != y->digit)
            return x->digit > y->digit ? 1 : -1;
        x = x->next;
        y = y->next;
    }
    return 0;
}

void add_abs(const BigInt *a, const BigInt *b, BigInt *result)
{
    int carry = 0;
    Dlist *x = a->tail, *y = b->tail;
    bigint_clear(result);

    while (x != NULL || y != NULL || carry != 0)
    {
        int sum = carry;
        if (x != NULL) { sum += x->digit; x = x->prev; }
        if (y != NULL) { sum += y->digit; y = y->prev; }
        prepend_digit(result, sum % 10);
        carry = sum / 10;
    }

    if (result->head == NULL)
        append_digit(result, 0);
    result->sign = 1;
    bigint_normalize(result);
}

void sub_abs(const BigInt *a, const BigInt *b, BigInt *result)
{
    /* Caller must ensure |a| >= |b|. */
    int borrow = 0;
    Dlist *x = a->tail, *y = b->tail;
    bigint_clear(result);

    while (x != NULL)
    {
        int diff = x->digit - borrow - (y != NULL ? y->digit : 0);
        if (diff < 0)
        {
            diff += 10;
            borrow = 1;
        }
        else
            borrow = 0;

        prepend_digit(result, diff);
        x = x->prev;
        if (y != NULL)
            y = y->prev;
    }

    if (result->head == NULL)
        append_digit(result, 0);
    result->sign = 1;
    bigint_normalize(result);
}