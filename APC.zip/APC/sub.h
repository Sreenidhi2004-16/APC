#ifndef SUB_H
#define SUB_H
#include "main.h"
int subtraction(const BigInt *a, const BigInt *b, BigInt *result);
#endif