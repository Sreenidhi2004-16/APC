#include "div.h"

static void shift_add_digit(BigInt *n, int digit)
{
    if (bigint_is_zero(n))
    {
        if (n->head != NULL)
            n->head->digit = digit;
        else
            append_digit(n, digit);
    }
    else
        append_digit(n, digit);
    n->sign = 1;
    bigint_normalize(n);
}

int division(const BigInt *a, const BigInt *b, BigInt *result)
{
    if (bigint_is_zero(b))
        return 0;

    bigint_clear(result);

    BigInt remainder, temp;
    bigint_init(&remainder);
    bigint_init(&temp);
    bigint_parse(&remainder, "0");

    for (Dlist *digit = a->head; digit != NULL; digit = digit->next)
    {
        shift_add_digit(&remainder, digit->digit);

        int qdigit = 0;
        while (compare_abs(&remainder, b) >= 0)
        {
            sub_abs(&remainder, b, &temp);
            bigint_clear(&remainder);
            remainder = temp;
            bigint_init(&temp);
            qdigit++;
        }
        append_digit(result, qdigit);
    }

    result->sign = a->sign * b->sign;
    bigint_normalize(result);
    bigint_clear(&remainder);
    bigint_clear(&temp);
    return 1;
}