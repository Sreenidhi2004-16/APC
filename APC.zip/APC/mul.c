#include "mul.h"

static int digit_count(const BigInt *n)
{
    int count = 0;
    for (Dlist *p = n->head; p != NULL; p = p->next)
        count++;
    return count;
}

int multiplication(const BigInt *a, const BigInt *b, BigInt *result)
{
    bigint_clear(result);

    if (bigint_is_zero(a) || bigint_is_zero(b))
    {
        bigint_parse(result, "0");
        return 1;
    }

    int na = digit_count(a), nb = digit_count(b);
    int *x = calloc((size_t)na, sizeof(int));
    int *y = calloc((size_t)nb, sizeof(int));
    int *out = calloc((size_t)(na + nb), sizeof(int));

    if (x == NULL || y == NULL || out == NULL)
    {
        free(x); free(y); free(out);
        return 0;
    }

    int i = 0;
    for (Dlist *p = a->head; p != NULL; p = p->next)
        x[i++] = p->digit;
    i = 0;
    for (Dlist *p = b->head; p != NULL; p = p->next)
        y[i++] = p->digit;

    /* Grade-school multiplication, using one array element per digit. */
    for (i = na - 1; i >= 0; i--)
    {
        int carry = 0;
        for (int j = nb - 1; j >= 0; j--)
        {
            int pos = i + j + 1;
            int value = x[i] * y[j] + out[pos] + carry;
            out[pos] = value % 10;
            carry = value / 10;
        }
        out[i] += carry;
    }

    int started = 0;
    for (i = 0; i < na + nb; i++)
    {
        if (out[i] != 0 || started || i == na + nb - 1)
        {
            append_digit(result, out[i]);
            started = 1;
        }
    }

    result->sign = a->sign * b->sign;
    bigint_normalize(result);

    free(x); free(y); free(out);
    return 1;
}