#ifndef ADD_H
#define ADD_H
#include "main.h"
int addition(const BigInt *a, const BigInt *b, BigInt *result);
#endif