#ifndef MUL_H
#define MUL_H
#include "main.h"
int multiplication(const BigInt *a, const BigInt *b, BigInt *result);
#endif