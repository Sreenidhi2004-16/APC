#include "sub.h"

int subtraction(const BigInt *a, const BigInt *b, BigInt *result)
{
    BigInt neg_b;
    bigint_init(&neg_b);

    for (Dlist *p = b->head; p != NULL; p = p->next)
        append_digit(&neg_b, p->digit);
    neg_b.sign = -b->sign;
    bigint_normalize(&neg_b);

    int status = addition(a, &neg_b, result);
    bigint_clear(&neg_b);
    return status;
}