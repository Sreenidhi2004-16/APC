//----------------Documentation----------------//
/*Name:Sreenidhi B S
  Project Name : Arbitrary Precision Calculator    
  Description:Implementation of APC (Arbitrary Precision Calculator)
*/

#include "main.h"
#include "add.h"
#include "sub.h"
#include "mul.h"
#include "div.h"

int main(int argc, char *argv[])
{
    BigInt num1, num2, result;

    bigint_init(&num1);
    bigint_init(&num2);
    bigint_init(&result);

    // Check the number of command-line arguments
    if (argc != 4)
    {
        printf("Usage: %s <num1> <operator> <num2>\n", argv[0]);
        return 1;
    }

    // Convert input strings into linked lists
    if (!bigint_parse(&num1, argv[1]) ||
        !bigint_parse(&num2, argv[3]))
    {
        printf("Error: Invalid number\n");
        bigint_clear(&num1);
        bigint_clear(&num2);
        bigint_clear(&result);
        return 1;
    }

    // Perform the requested operation
    int status = 1;

    switch (argv[2][0])
    {
        case '+':
            if (argv[2][1] == '\0')
                status = addition(&num1, &num2, &result);
            else
                status = 0;
            break;

        case '-':
            if (argv[2][1] == '\0')
                status = subtraction(&num1, &num2, &result);
            else
                status = 0;
            break;

        case '*':
            if (argv[2][1] == '\0')
                status = multiplication(&num1, &num2, &result);
            else
                status = 0;
            break;

        case '/':
            if (argv[2][1] == '\0')
                status = division(&num1, &num2, &result);
            else
                status = 0;
            break;

        default:
            status = 0;
    }

    if (status)
    {
        bigint_print(&result);
        printf("\n");
    }
    else
    {
        printf("Error: Invalid operator or division by zero\n");
    }

    bigint_clear(&num1);
    bigint_clear(&num2);
    bigint_clear(&result);

    return status ? 0 : 1;
}