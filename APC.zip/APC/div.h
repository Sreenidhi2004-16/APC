#ifndef DIV_H
#define DIV_H
#include "main.h"
/* Integer division. Quotient is truncated toward zero. Returns 0 if divisor is zero. */
int division(const BigInt *a, const BigInt *b, BigInt *result);
#endif