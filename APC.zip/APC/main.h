#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Each node stores one decimal digit. Digits are stored left to right:
   123 is stored as 1 <-> 2 <-> 3. */
typedef struct node
{
    int digit;
    struct node *prev;
    struct node *next;
} Dlist;

typedef struct
{
    Dlist *head;
    Dlist *tail;
    int sign; /* -1 for negative, 0 for zero, 1 for positive */
} BigInt;

void bigint_init(BigInt *n);
void bigint_clear(BigInt *n);
int bigint_parse(BigInt *n, const char *text);
void bigint_print(const BigInt *n);
int bigint_is_zero(const BigInt *n);
int compare_abs(const BigInt *a, const BigInt *b);
void add_abs(const BigInt *a, const BigInt *b, BigInt *result);
void sub_abs(const BigInt *a, const BigInt *b, BigInt *result); /* requires |a| >= |b| */
void append_digit(BigInt *n, int digit);
void prepend_digit(BigInt *n, int digit);
void bigint_normalize(BigInt *n);

int addition(const BigInt *a, const BigInt *b, BigInt *result);
int subtraction(const BigInt *a, const BigInt *b, BigInt *result);
int multiplication(const BigInt *a, const BigInt *b, BigInt *result);
int division(const BigInt *a, const BigInt *b, BigInt *result);

#endif